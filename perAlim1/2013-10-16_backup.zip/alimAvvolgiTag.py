#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Questo script 'avvolge' (wrapping) i tag HTML con le parentesi quadre,
# cambiando ad esempio "<B>verbum</B>" in "[<B>] verbum [</B>]"
# (vd. Norme_ALIM_1.1.pdf, paragrafo 4.2). Prende come input un file html
# e scrive l'output in un altro file html con "_3.0" alla fine del nome file.

import os
import re
import alimGestisciFile

os.system('clear')

oldFile = alimGestisciFile.scegli('html')
if oldFile == '':
        exit('Esco perché non ho niente da fare')

# Effettua effettivamente le sostituzioni e scrive l'output

a=open(oldFile,'r')
b=open(alimGestisciFile.nuovaVersione(oldFile),'w')

for line in a.readlines():
	# "?" rende "*" non-greedy
	#
	# Tag d'apertura (ci mette uno spazio dopo):
	line = re.sub(r'(<\w.*?>)',r'[\1] ',line)
	# Tag di chiusura (ci mette uno spazio prima):
	line = re.sub(r'(<\/.*?>)',r' [\1]',line)
	print(line, file=b, end='')

a.close()
b.close()
